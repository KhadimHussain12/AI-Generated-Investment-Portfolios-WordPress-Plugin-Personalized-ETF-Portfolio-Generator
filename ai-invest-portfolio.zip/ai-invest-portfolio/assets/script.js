// Client-side portfolio generator (vanilla JS)
(function(){
    function byId(id){return document.getElementById(id);}
    var genBtn = byId('aigp-generate');
    var saveBtn = byId('aigp-save');
    var loadBtn = byId('aigp-load');
    var resultsWrap = byId('aigp-results-wrap');
    var tableBody = byId('aigp-table').getElementsByTagName('tbody')[0];
    var summary = byId('aigp-summary');
    var exportCsvBtn = byId('aigp-export-csv');
    var exportPdfBtn = byId('aigp-export-pdf');

    function getSelectedValues(){
        var boxes = document.querySelectorAll('#aigp-app .aigp-values input[type="checkbox"]');
        var res=[];
        boxes.forEach(function(b){ if(b.checked) res.push(b.value); });
        return res;
    }

    function deterministicPortfolio(amount, horizon, risk, values){
        // Base ETF pool (examples) — client-side only, no external calls
        var etfs = [
            {ticker:'VTI', name:'US Total Market ETF', type:'equity'},
            {ticker:'VOO', name:'US Large Cap ETF', type:'equity'},
            {ticker:'VEA', name:'Developed Markets ETF', type:'intl'},
            {ticker:'VWO', name:'Emerging Markets ETF', type:'intl'},
            {ticker:'BND', name:'US Aggregate Bond ETF', type:'bond'},
            {ticker:'BNDX', name:'International Bond ETF', type:'bond'},
            {ticker:'VNQ', name:'US REIT ETF', type:'realestate'},
            {ticker:'VIG', name:'Dividend Growth ETF', type:'income'},
            {ticker:'IWM', name:'Small Cap ETF', type:'smallcap'}
        ];

        // Start with a base allocation by risk
        var alloc = [];
        if(risk==='conservative'){
            alloc = {'bond':60,'equity':30,'realestate':5,'intl':5};
        } else if(risk==='balanced'){
            alloc = {'bond':30,'equity':55,'realestate':5,'intl':10};
        } else { // growth
            alloc = {'bond':10,'equity':65,'realestate':5,'intl':20};
        }

        // Adjust for horizon (longer horizon -> more equity)
        if(horizon >= 10){ alloc['equity'] += 5; alloc['bond'] = Math.max(0, alloc['bond'] - 5); }
        if(horizon <= 3){ alloc['bond'] += 5; alloc['equity'] = Math.max(0, alloc['equity'] - 5); }

        // Adjust for values
        if(values.indexOf('income') !== -1){ /* favour dividend */ alloc['equity'] += 5; alloc['bond'] += 5; }
        if(values.indexOf('smallcap') !== -1){ alloc['equity'] += 5; alloc['intl'] += 2; }
        if(values.indexOf('international') !== -1){ alloc['intl'] += 5; alloc['equity'] = Math.max(0, alloc['equity']-5); }
        if(values.indexOf('esg') !== -1){ /* annotate choices */ }

        // Normalize total to 100
        var total = 0; for(var k in alloc) total += alloc[k];
        for(var k in alloc) alloc[k] = Math.round((alloc[k]/total)*100);

        // Map to ETFs with simple rules
        var result = [];
        // equity -> VTI, VOO, IWM mix
        var equityPct = alloc['equity'] || 0;
        var bondPct = alloc['bond'] || 0;
        var intlPct = alloc['intl'] || 0;
        var rePct = alloc['realestate'] || 0;

        // deterministic weight split
        if(equityPct>0){
            var vti = Math.round(equityPct * 0.6);
            var voo = Math.round(equityPct * 0.25);
            var iwm = Math.round(equityPct * 0.15);
            result.push({ticker:'VTI', name:'US Total Market ETF', allocation:vti, notes:''});
            result.push({ticker:'VOO', name:'US Large Cap ETF', allocation:voo, notes:''});
            if(values.indexOf('smallcap')!==-1) result.push({ticker:'IWM', name:'US Small Cap ETF', allocation:iwm, notes:'Small-cap tilt'});
        }
        if(intlPct>0){
            var vea = Math.round(intlPct * 0.7);
            var vwo = Math.round(intlPct * 0.3);
            result.push({ticker:'VEA', name:'Developed Markets ETF', allocation:vea, notes:''});
            result.push({ticker:'VWO', name:'Emerging Markets ETF', allocation:vwo, notes:''});
        }
        if(bondPct>0){
            var bnd = Math.round(bondPct * 0.8);
            var bndx = Math.round(bondPct * 0.2);
            result.push({ticker:'BND', name:'US Aggregate Bond ETF', allocation:bnd, notes:''});
            result.push({ticker:'BNDX', name:'International Bond ETF', allocation:bndx, notes:''});
        }
        if(rePct>0){
            result.push({ticker:'VNQ', name:'US REIT ETF', allocation:rePct, notes:'Real estate exposure'});
        }

        // Adjust rounding to sum 100
        var sum=0; for(var i=0;i<result.length;i++) sum+=result[i].allocation;
        var diff = 100 - sum;
        if(diff !== 0 && result.length>0){ result[0].allocation += diff; }

        // If ESG requested, add notes
        if(values.indexOf('esg')!==-1){
            result = result.map(function(r){ r.notes = (r.notes? r.notes+'; ':'') + 'ESG-friendly option suggested'; return r; });
        }
        if(values.indexOf('tax')!==-1){
            result = result.map(function(r){ r.notes = (r.notes? r.notes+'; ':'') + 'Tax-efficient ETF'; return r; });
        }
        if(values.indexOf('income')!==-1){
            result = result.map(function(r){
                if(r.ticker==='VIG' || r.ticker==='VNQ' || r.ticker==='BND'){ r.notes = (r.notes? r.notes+'; ':'') + 'Income oriented'; }
                return r;
            });
        }

        return result;
    }

    function renderTable(items, amount, name){
        tableBody.innerHTML='';
        items.forEach(function(it){
            var tr = document.createElement('tr');
            var td1 = document.createElement('td'); td1.textContent = it.ticker + ' — ' + it.name;
            var td2 = document.createElement('td'); td2.textContent = it.allocation + '% (' + Math.round((it.allocation/100)*amount) + ' USD)';
            var td3 = document.createElement('td'); td3.textContent = it.notes || '';
            tr.appendChild(td1); tr.appendChild(td2); tr.appendChild(td3);
            tableBody.appendChild(tr);
        });
        summary.textContent = (name? name + ', ':'') + 'Suggested allocation for $' + amount + '.';
        resultsWrap.style.display = 'block';
    }

    function exportCSV(items){
        var rows = [['Ticker','Name','Allocation %','Amount USD','Notes']];
        var amount = parseFloat(byId('aigp-amount').value) || 0;
        items.forEach(function(it){
            var amt = Math.round((it.allocation/100)*amount);
            rows.push([it.ticker, it.name, it.allocation, amt, it.notes || '']);
        });
        var csv = rows.map(function(r){ return r.map(function(c){ return '"'+String(c).replace(/"/g,'""')+'"'; }).join(','); }).join('\n');
        var blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a'); a.href = url; a.download = 'portfolio.csv'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    }

    function exportPDF(items){
        var w = window.open('', '_blank', 'width=900,height=700');
        var name = byId('aigp-name').value || '';
        var amount = parseFloat(byId('aigp-amount').value) || 0;
        var notes = byId('aigp-notes').value || '';
        var html = '<!doctype html><html><head><meta charset="utf-8"><title>Portfolio</title><style>body{font-family:Arial,Helvetica,sans-serif;padding:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:8px;text-align:left}h2{margin-top:0}</style></head><body>';
        html += '<h2>AI‑Generated Investment Portfolio</h2>';
        if(name) html += '<p><strong>Investor:</strong> '+escapeHtml(name)+'</p>';
        html += '<p><strong>Amount:</strong> $'+amount+'</p>';
        html += '<p><strong>Notes:</strong> '+escapeHtml(notes)+'</p>';
        html += '<table><thead><tr><th>ETF</th><th>Allocation %</th><th>Amount (USD)</th><th>Notes</th></tr></thead><tbody>';
        items.forEach(function(it){
            var amt = Math.round((it.allocation/100)*amount);
            html += '<tr><td>'+escapeHtml(it.ticker+' — '+it.name)+'</td><td>'+it.allocation+'%</td><td>$'+amt+'</td><td>'+escapeHtml(it.notes || '')+'</td></tr>';
        });
        html += '</tbody></table>';
        html += '<p style="font-size:12px;color:#666">Disclaimer: Results are AI-generated for educational use only. Not financial advice.</p>';
        html += '</body></html>';
        w.document.open(); w.document.write(html); w.document.close();
        setTimeout(function(){ w.print(); }, 600);
    }

    function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

    genBtn.addEventListener('click', function(){
        var amount = parseFloat(byId('aigp-amount').value) || 0;
        var horizon = parseInt(byId('aigp-horizon').value) || 10;
        var risk = byId('aigp-risk').value || 'balanced';
        var values = getSelectedValues();
        var name = byId('aigp-name').value || '';
        var items = deterministicPortfolio(amount, horizon, risk, values);
        renderTable(items, amount, name);
    });

    saveBtn.addEventListener('click', function(){
        var prefs = {
            name: byId('aigp-name').value || '',
            amount: byId('aigp-amount').value || '',
            horizon: byId('aigp-horizon').value || '',
            risk: byId('aigp-risk').value || '',
            values: getSelectedValues(),
            notes: byId('aigp-notes').value || ''
        };
        var fd = new FormData();
        fd.append('action','aigp_save_prefs');
        fd.append('data', JSON.stringify(prefs));
        fetch(AIGP_Ajax.ajax_url, {method:'POST', credentials:'same-origin', body:fd}).then(function(r){ return r.json(); }).then(function(j){ if(j.success) alert('Preferences saved'); else alert('Save failed'); }).catch(function(){ alert('Save failed'); });
    });

    loadBtn.addEventListener('click', function(){
        var fd = new FormData();
        fd.append('action','aigp_load_prefs');
        fetch(AIGP_Ajax.ajax_url, {method:'POST', credentials:'same-origin', body:fd}).then(function(r){ return r.json(); }).then(function(j){
            if(j.success && j.data){
                try{
                    var p = JSON.parse(j.data);
                    byId('aigp-name').value = p.name || '';
                    byId('aigp-amount').value = p.amount || '';
                    byId('aigp-horizon').value = p.horizon || '10';
                    byId('aigp-risk').value = p.risk || 'balanced';
                    byId('aigp-notes').value = p.notes || '';
                    // set checkboxes
                    var boxes = document.querySelectorAll('#aigp-app .aigp-values input[type="checkbox"]');
                    boxes.forEach(function(b){ b.checked = (p.values && p.values.indexOf(b.value)!==-1); });
                    alert('Preferences loaded');
                }catch(e){ alert('Invalid saved data'); }
            } else alert('Load failed');
        }).catch(function(){ alert('Load failed'); });
    });

    exportCsvBtn.addEventListener('click', function(){
        var rows = [];
        var trs = tableBody.querySelectorAll('tr');
        trs.forEach(function(tr){
            var tds = tr.querySelectorAll('td');
            if(tds.length){
                var ticker = tds[0].textContent.split(' — ')[0].trim();
                var name = tds[0].textContent.split(' — ').slice(1).join(' — ').trim();
                var alloc = parseFloat(tds[1].textContent) || 0;
                var notes = tds[2].textContent || '';
                rows.push({ticker:ticker, name:name, allocation:alloc, notes:notes});
            }
        });
        if(!rows.length){ alert('No portfolio to export'); return; }
        exportCSV(rows);
    });

    exportPdfBtn.addEventListener('click', function(){
        var rows = [];
        var trs = tableBody.querySelectorAll('tr');
        trs.forEach(function(tr){
            var tds = tr.querySelectorAll('td');
            if(tds.length){
                var ticker = tds[0].textContent.split(' — ')[0].trim();
                var name = tds[0].textContent.split(' — ').slice(1).join(' — ').trim();
                var alloc = parseFloat(tds[1].textContent) || 0;
                var notes = tds[2].textContent || '';
                rows.push({ticker:ticker, name:name, allocation:alloc, notes:notes});
            }
        });
        if(!rows.length){ alert('No portfolio to export'); return; }
        exportPDF(rows);
    });

})();

AI‑Generated Investment Portfolios (Basic Safe Version)
-----------------------------------------------------------
Shortcode: [ai_invest_portfolio]

Description:
- Generates hyper-personalized ETF portfolios client-side based on user inputs: amount, time horizon, risk tolerance, values, and goals.
- Deterministic, educational-only suggestions (no external API calls by default).
- Client-side CSV export and printable PDF (use browser Save as PDF).

Disclaimer: Results are AI-generated for educational use only. This is not financial advice. Consult a licensed professional before investing.

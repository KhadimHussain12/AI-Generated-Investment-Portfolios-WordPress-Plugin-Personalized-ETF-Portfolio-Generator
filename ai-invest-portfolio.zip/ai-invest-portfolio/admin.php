<?php
if (!defined('ABSPATH')) exit;

function aigp_admin_menu() {
    add_menu_page('AI Investment Portfolios', 'AI Portfolios', 'manage_options', 'aigp-admin', 'aigp_admin_page', 'dashicons-money-alt');
}
add_action('admin_menu', 'aigp_admin_menu');

function aigp_admin_page() {
    ?>
    <div class="wrap">
        <h1>AI‑Generated Investment Portfolios — Settings</h1>
        <p>Use the shortcode <code>[ai_invest_portfolio]</code> in any post or page to show the frontend UI.</p>
        <h2>Saved Preferences</h2>
        <textarea id="aigp-admin-prefs" style="width:100%;min-height:200px;"><?php echo esc_textarea( get_option('aigp_saved_prefs','') ); ?></textarea>
        <p><button id="aigp-admin-save" class="button button-primary">Save</button></p>
        <hr />
        <h2>About</h2>
        <p>Basic Safe Version (no external API calls). Portfolio suggestions are generated deterministically client-side from inputs for demonstration and educational purposes. Not financial advice.</p>
    </div>
    <?php
}
